package com.project.main;

public class Ejecucion {

	public static void main(String[] args) {

		Ley L = new Ley();
		L.setVisible(true);
		L.setLocationRelativeTo(null);
		L.setTitle("Ley de Hooke");

	}

}
